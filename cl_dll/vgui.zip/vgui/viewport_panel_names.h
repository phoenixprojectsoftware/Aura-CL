#ifndef VGUI_VIEWPORT_PANEL_NAMES_H
#define VGUI_VIEWPORT_PANEL_NAMES_H

#define PANEL_SCOREBOARD "scoreboard"

#endif
